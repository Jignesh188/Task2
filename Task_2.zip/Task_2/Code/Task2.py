import requests
from bs4 import BeautifulSoup
import csv

# Function to scrape categories and subcategories from Amazon.in
def scrape_amazon_categories():
    url = 'https://www.amazon.in/'  # Amazon India site directory for categories
    
    headers = {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36"
    }

    # Send a request to get the page content
    response = requests.get(url, headers=headers)
    if response.status_code != 200:
        print(f"Failed to retrieve content from Amazon. Status code: {response.status_code}")
        return []

    # Parse the content with BeautifulSoup
    soup = BeautifulSoup(response.text, 'html.parser')

    # List to store the categories and subcategories
    categories = []

    # Searching for category links in the page
    for category in soup.find_all('div', class_='sitemapLinkColumn'):
        category_name = category.find_previous('h2').text.strip() if category.find_previous('h2') else 'No Category Name'
        for link in category.find_all('a'):
            subcategory_name = link.get_text().strip()
            subcategory_url = link.get('href')
            if subcategory_url:
                categories.append({
                    'Category': category_name,
                    'Subcategory': subcategory_name,
                    'URL': subcategory_url
                })

    return categories

# Function to save data to CSV
def save_to_csv(data, filename='amazon_categories.csv'):
    keys = data[0].keys()
    with open(filename, 'w', newline='', encoding='utf-8') as output_file:
        dict_writer = csv.DictWriter(output_file, fieldnames=keys)
        dict_writer.writeheader()
        dict_writer.writerows(data)
    print(f"Data saved to {filename}")

# Scrape the categories and subcategories
categories = scrape_amazon_categories()

# If categories are found, save them to CSV
if categories:
    save_to_csv(categories)
else:
    print("No categories found.")
